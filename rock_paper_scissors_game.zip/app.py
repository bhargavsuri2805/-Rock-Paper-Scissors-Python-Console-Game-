import os
import logging
from flask import Flask, render_template, request, jsonify, session
from game import Choice, GameResult, determine_winner
import random

# Configure logging for easier debugging
logging.basicConfig(level=logging.DEBUG)

# Create the Flask application
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "rock_paper_scissors_secret")

@app.route('/')
def index():
    """Render the main landing page"""
    return render_template('index.html')

@app.route('/game')
def game():
    """Render the game page"""
    # Reset the game state when starting a new game
    rounds = request.args.get('rounds', 3, type=int)
    
    session['rounds'] = rounds
    session['current_round'] = 1
    session['player_score'] = 0
    session['computer_score'] = 0
    session['game_history'] = []
    
    return render_template('game.html', rounds=rounds)

@app.route('/play', methods=['POST'])
def play():
    """Handle a player's move"""
    # Get player choice from form data
    player_choice_str = request.form.get('choice')
    
    try:
        # Convert string to Choice enum
        player_choice = Choice[player_choice_str.upper()]
        
        # Get computer choice
        computer_choice = random.choice(list(Choice))
        
        # Determine the winner
        result = determine_winner(player_choice, computer_choice)
        
        # Update scores
        if result == GameResult.WIN:
            session['player_score'] = session.get('player_score', 0) + 1
            result_text = "You win this round!"
        elif result == GameResult.LOSE:
            session['computer_score'] = session.get('computer_score', 0) + 1
            result_text = "Computer wins this round!"
        else:
            result_text = "It's a tie!"
            
        # Update current round
        current_round = session.get('current_round', 1)
        
        # Store round results in history
        round_result = {
            'round': current_round,
            'player_choice': player_choice.name,
            'computer_choice': computer_choice.name,
            'result': result.name,
            'result_text': result_text
        }
        
        # Add to history
        history = session.get('game_history', [])
        history.append(round_result)
        session['game_history'] = history
        
        # Increment the round
        session['current_round'] = current_round + 1
        
        # Check if the game is over
        total_rounds = session.get('rounds', 3)
        game_over = current_round >= total_rounds
        
        # Determine final game result if the game is over
        final_result = None
        if game_over:
            player_score = session.get('player_score', 0)
            computer_score = session.get('computer_score', 0)
            
            if player_score > computer_score:
                final_result = "🎉 Congratulations! You won the game!"
            elif player_score < computer_score:
                final_result = "😞 Computer won the game. Better luck next time!"
            else:
                final_result = "🤝 It's a draw!"
        
        # Return the results as JSON for AJAX handling
        return jsonify({
            'player_choice': player_choice.name,
            'computer_choice': computer_choice.name,
            'result': result.name,
            'result_text': result_text,
            'player_score': session.get('player_score', 0),
            'computer_score': session.get('computer_score', 0),
            'current_round': current_round,
            'total_rounds': total_rounds,
            'game_over': game_over,
            'final_result': final_result
        })
        
    except (KeyError, ValueError) as e:
        return jsonify({'error': f"Invalid choice: {player_choice_str}. Choose rock, paper, or scissors."}), 400

@app.route('/reset', methods=['POST'])
def reset_game():
    """Reset the game state for a new game"""
    rounds = request.form.get('rounds', 3, type=int)
    
    session['rounds'] = rounds
    session['current_round'] = 1
    session['player_score'] = 0
    session['computer_score'] = 0
    session['game_history'] = []
    
    return jsonify({'success': True, 'rounds': rounds})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
