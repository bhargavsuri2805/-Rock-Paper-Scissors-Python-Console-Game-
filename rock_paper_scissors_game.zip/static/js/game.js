document.addEventListener('DOMContentLoaded', function() {
    // Cache DOM elements
    const roundInfo = document.getElementById('round-info');
    const playerChoices = document.querySelectorAll('.choice-btn');
    const resultContainer = document.getElementById('result-container');
    const scoreDisplay = document.getElementById('score-display');
    const playAgainBtn = document.getElementById('play-again-btn');
    const changeRoundsBtn = document.getElementById('change-rounds-btn');
    const gameHistoryBody = document.getElementById('game-history-body');
    const gameContainer = document.getElementById('game-container');
    const finalResultContainer = document.getElementById('final-result-container');
    const finalResultText = document.getElementById('final-result-text');
    const playerChoiceDisplay = document.getElementById('player-choice');
    const computerChoiceDisplay = document.getElementById('computer-choice');
    const roundResult = document.getElementById('round-result');
    
    // Add event listeners to player choice buttons
    playerChoices.forEach(button => {
        button.addEventListener('click', function() {
            makeChoice(this.dataset.choice);
        });
    });
    
    // Add event listener to play again button
    if (playAgainBtn) {
        playAgainBtn.addEventListener('click', function() {
            resetGame();
        });
    }
    
    /**
     * Make a player choice and send it to the server
     * @param {string} choice - The player's choice (rock, paper, scissors)
     */
    function makeChoice(choice) {
        // Disable all buttons during processing
        playerChoices.forEach(btn => btn.disabled = true);
        
        // Create form data for the request
        const formData = new FormData();
        formData.append('choice', choice);
        
        // Send the choice to the server
        fetch('/play', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                showError(data.error);
                return;
            }
            
            // Update the UI with the round results
            updateRoundResult(data);
            
            // Update the score display
            updateScore(data.player_score, data.computer_score);
            
            // Update the round information
            updateRoundInfo(data.current_round, data.total_rounds);
            
            // Add the round to the history table
            addToHistory(data);
            
            // Check if the game is over
            if (data.game_over) {
                showFinalResult(data);
            }
            
            // Re-enable the buttons if the game is not over
            if (!data.game_over) {
                playerChoices.forEach(btn => btn.disabled = false);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showError('An error occurred while processing your choice.');
            // Re-enable the buttons
            playerChoices.forEach(btn => btn.disabled = false);
        });
    }
    
    /**
     * Update the round result display
     * @param {Object} data - The response data from the server
     */
    function updateRoundResult(data) {
        // Show the result container
        resultContainer.classList.remove('d-none');
        
        // Update the player's choice display
        playerChoiceDisplay.textContent = data.player_choice.toLowerCase();
        playerChoiceDisplay.className = 'choice-text'; // Reset classes
        playerChoiceDisplay.classList.add(data.player_choice.toLowerCase());
        
        // Update the computer's choice display
        computerChoiceDisplay.textContent = data.computer_choice.toLowerCase();
        computerChoiceDisplay.className = 'choice-text'; // Reset classes
        computerChoiceDisplay.classList.add(data.computer_choice.toLowerCase());
        
        // Update the round result text
        roundResult.textContent = data.result_text;
        roundResult.className = 'alert'; // Reset classes
        
        // Add appropriate class based on the result
        if (data.result === 'WIN') {
            roundResult.classList.add('alert-success');
        } else if (data.result === 'LOSE') {
            roundResult.classList.add('alert-danger');
        } else {
            roundResult.classList.add('alert-warning');
        }
    }
    
    /**
     * Update the score display
     * @param {number} playerScore - The player's score
     * @param {number} computerScore - The computer's score
     */
    function updateScore(playerScore, computerScore) {
        scoreDisplay.textContent = `You: ${playerScore} | Computer: ${computerScore}`;
    }
    
    /**
     * Update the round information display
     * @param {number} currentRound - The current round number
     * @param {number} totalRounds - The total number of rounds
     */
    function updateRoundInfo(currentRound, totalRounds) {
        roundInfo.textContent = `Round ${currentRound} of ${totalRounds}`;
    }
    
    /**
     * Add a round to the game history table
     * @param {Object} data - The response data from the server
     */
    function addToHistory(data) {
        // Create a new row for the history table
        const row = document.createElement('tr');
        
        // Create and append table cells
        const roundCell = document.createElement('td');
        roundCell.textContent = data.current_round;
        row.appendChild(roundCell);
        
        const playerChoiceCell = document.createElement('td');
        playerChoiceCell.textContent = data.player_choice.toLowerCase();
        row.appendChild(playerChoiceCell);
        
        const computerChoiceCell = document.createElement('td');
        computerChoiceCell.textContent = data.computer_choice.toLowerCase();
        row.appendChild(computerChoiceCell);
        
        const resultCell = document.createElement('td');
        resultCell.textContent = data.result_text;
        
        // Add appropriate class based on the result
        if (data.result === 'WIN') {
            resultCell.classList.add('text-success');
        } else if (data.result === 'LOSE') {
            resultCell.classList.add('text-danger');
        } else {
            resultCell.classList.add('text-warning');
        }
        
        row.appendChild(resultCell);
        
        // Add the row to the history table
        gameHistoryBody.appendChild(row);
    }
    
    /**
     * Show the final result of the game
     * @param {Object} data - The response data from the server
     */
    function showFinalResult(data) {
        // Show the final result container
        finalResultContainer.classList.remove('d-none');
        
        // Update the final result text
        finalResultText.textContent = data.final_result;
        
        // Show the play again button
        playAgainBtn.classList.remove('d-none');
        changeRoundsBtn.classList.remove('d-none');
    }
    
    /**
     * Reset the game
     */
    function resetGame() {
        // Get the number of rounds from the current URL
        const urlParams = new URLSearchParams(window.location.search);
        const rounds = urlParams.get('rounds') || 3;
        
        // Create form data for the request
        const formData = new FormData();
        formData.append('rounds', rounds);
        
        // Send the reset request to the server
        fetch('/reset', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Reload the page to reset the game
                window.location.reload();
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showError('An error occurred while resetting the game.');
        });
    }
    
    /**
     * Show an error message
     * @param {string} message - The error message to display
     */
    function showError(message) {
        // Create an alert element
        const alert = document.createElement('div');
        alert.className = 'alert alert-danger';
        alert.textContent = message;
        
        // Add the alert to the top of the game container
        gameContainer.prepend(alert);
        
        // Remove the alert after 5 seconds
        setTimeout(() => {
            alert.remove();
        }, 5000);
    }
});
